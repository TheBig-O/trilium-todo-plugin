module.exports = async function (taskNoteId) {
  const taskNote = await api.getNote(taskNoteId);

  if (!taskNote) {
    return;
  }

  taskNote.removeLabel("timeLeft");
  taskNote.removeLabel("dueDate");

  await taskNote.save();
};
