module.exports = async function (notesIds) {
  for await (const noteId of notesIds) {
    await taskStartTracking(noteId);
  }
};
