module.exports = async function (notesIds) {
  for await (const noteId of notesIds) {
    await taskUnschedule(noteId);
  }
};
