module.exports = async function (notesIds) {
  const today = api.dayjs().format("YYYY-MM-DD");

  for await (const noteId of notesIds) {
    const note = await api.getNote(noteId);
    note.setLabel("completedDate", today);
  }
};
