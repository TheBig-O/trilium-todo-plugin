module.exports = async function (taskNoteId) {
  const taskNote = await api.getNote(taskNoteId);

  if (!taskNote) {
    return;
  }


//const taskNote = api.originEntity;
const content = taskNote.getContent();
var text = String(content);
var parts = text.split(/<hr[^>]*>/i);


text = parts[0];

text = text.replaceAll("</p>","");
text = text.replaceAll("&nbsp;"," ");    
parts = text.split("<p>");

//Should check if there is a description at all, otherwise, return... or erase?

//Array of description points
parts.shift();
const size = parts.length;
const myArray = new Array(size);

for (let i = 0; i < size; i++) {
    myArray[i] = parts[i];
}

//Remove all pre-existing values of the label before adding the updated ones.
  taskNote.removeLabel("descriptionLabel"); 

for (let i = 0; i < size; i++) {
  taskNote.addLabel("descriptionLabel", myArray[i]);
}

};