(async function () {
  await api.runAsyncOnBackendWithManualTransactionHandling(async () => {
    const timelines = await api.getNotesWithLabel("initTimeline");

    const timelineRenderNote = await api.getNotesWithLabel(
      "todoTimelineView"
    )[0];

    for await (const timeline of timelines) {
      timeline.type = "render";
      timeline.setLabel("todoTimeline", "");
      timeline.setRelation("renderNote", timelineRenderNote.noteId);
      timeline.removeLabel("initTimeline");

      await timeline.save();
    }
  }, []);

  await api.waitUntilSynced();
})();
