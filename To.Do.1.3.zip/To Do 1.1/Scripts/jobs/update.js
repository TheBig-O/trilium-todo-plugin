(async function () {
  async function updateTasksNotesTimeLeft() {
//   Changed below to eliminate async error
      await api.runAsyncOnBackendWithManualTransactionHandling(async () => {
      const tasksNotes = await api
        .getNotesWithLabel("todoItem")
        .filter((m) => m.hasLabel("dueDate"))
        .map((m) => m.noteId);

      for await (const taskNote of tasksNotes) {
        await taskUpdateTimeLeft(taskNote);
      }
    });
  }

  setInterval(async () => {
    await updateTasksNotesTimeLeft();
  }, 60000);
})();
