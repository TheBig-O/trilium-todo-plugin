api.dayjs.extend(dayjsDuration);
api.dayjs.extend(dayjsRelativeTime);