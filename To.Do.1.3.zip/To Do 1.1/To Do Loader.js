// Created to load dayjs file and eliminate this error: (10/4/2025)
// Execution of JS note "front-end" with ID jQAWxp2El5Lv failed with error: Load of script note "front-end" (jQAWxp2El5Lv) failed with: dayjs is not defined

// Loader note: loads Day.js and front-end safely on startup
(async function () {
    try {
        // Only load Day.js if it isn't already defined
        if (typeof dayjs === "undefined") {
            await api.loadScript('dayjs');
            await api.loadScript('dayjsDuration');
            await api.loadScript('dayjsRelativeTime');
        }

        // Now safely load and execute your front-end logic
        await api.loadScript('front-end');

        console.log('✅ Day.js and front-end loaded successfully.');
    } catch (err) {
        console.error('❌ Error loading scripts:', err);
    }
})();
